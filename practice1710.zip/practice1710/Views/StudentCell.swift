import Foundation
import UIKit
import SnapKit

final class StudentCell: UITableViewCell {
    
    private let PFIcon: UIImageView = {
        let imageView = UIImageView()
        
        imageView.backgroundColor = .black
        imageView.layer.cornerRadius = 10
        imageView.layer.shadowColor = UIColor.black.cgColor
        imageView.layer.shadowOpacity = 0.4
        
        return imageView
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18, weight: .bold)
        
        return label
    }()
    
    private let ageLabel: UILabel = {
        let label = UILabel()
        
        label.font = .systemFont(ofSize: 16, weight: .heavy)
        label.textColor = .orange
        
        return label
    }()
    
    private let scoreLabel: UILabel = {
        let label = UILabel()
        
        label.font = .systemFont(ofSize: 16, weight: .heavy)
        label.textColor = .orange
        
        return label
    }()
    
    private let scholarshipLabel: UILabel = {
        let label = UILabel()
        
        return label
    }()
    
    private let scholarshipStatus: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 10
        return imageView
    }()

    
    public static let identifier = "student"
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupView()
        setupLayout()
    }
    
    init() {
        super.init(style: .default, reuseIdentifier: "StudentCell")
        setupView()
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
            super.prepareForReuse()
            
            PFIcon.image = nil
            nameLabel.text = nil
            ageLabel.text = nil
            scoreLabel.text = nil
            scholarshipLabel.text = nil
            scholarshipStatus.image = nil
        }
    
    private func setupLayout() {
        PFIcon.snp.makeConstraints {
            $0.top.trailing.bottom.equalToSuperview().inset(6)
            $0.width.equalTo(138)
        }
        
        nameLabel.snp.makeConstraints {
            $0.top.leading.equalToSuperview().inset(6)
        }
        
        ageLabel.snp.makeConstraints {
            $0.top.equalTo(nameLabel.snp.bottom).offset(6)
            $0.leading.equalTo(nameLabel)
        }
        
        scoreLabel.snp.makeConstraints {
            $0.top.equalTo(ageLabel.snp.bottom).offset(6)
            $0.leading.equalTo(nameLabel)
        }

        scholarshipLabel.snp.makeConstraints {
            $0.top.equalTo(scoreLabel.snp.bottom).offset(6)
            $0.leading.equalTo(nameLabel)
        }
        
        scholarshipStatus.snp.makeConstraints {
            $0.top.equalTo(scoreLabel.snp.bottom).offset(6)
            $0.leading.equalTo(nameLabel)
        }
        
    }
    
    private func setupView() {
        
        addSubview(PFIcon)
        addSubview(nameLabel)
        addSubview(ageLabel)
        addSubview(scoreLabel)
        addSubview(scholarshipLabel)
        addSubview(scholarshipStatus)
    }
    
    func setupCell(with student: Student) {
        nameLabel.text = student.name
        ageLabel.text = "Age: \(student.age ?? 0)"
        if let scores = student.scores {
            scoreLabel.text = "Scores: \(scores)"
        } else {
            scoreLabel.text = "Scores: no scores"
        }
        
        if let hasScholarship = student.hasScholarship {
            scholarshipLabel.text = "Scholarship: \(hasScholarship ? "Yes" : "No")"
            let imageName = hasScholarship ? "checkmark.circle.fill" : "xmark.circle.fill"
            scholarshipStatus.image = UIImage(systemName: imageName)
        } else {
            scholarshipLabel.text = "Scholarship: Not mentioned"
            scholarshipStatus.image = UIImage(systemName: "questionmark.circle")
        }
    }

    
}
